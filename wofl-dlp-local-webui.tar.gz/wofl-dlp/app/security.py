from __future__ import annotations

from urllib.parse import urlparse

from fastapi import Header, HTTPException, Request

LOCAL_ORIGINS = {
    "http://127.0.0.1:8765",
    "http://localhost:8765",
}


def validate_media_url(url: str) -> str:
    url = url.strip()
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"}:
        raise HTTPException(status_code=400, detail="Only http:// and https:// URLs are accepted.")
    if not parsed.netloc:
        raise HTTPException(status_code=400, detail="URL is missing a host.")
    return url


def require_local_origin(request: Request) -> None:
    origin = request.headers.get("origin")
    if origin and origin not in LOCAL_ORIGINS:
        raise HTTPException(status_code=403, detail="Refused non-local browser origin.")


def require_token(expected_token: str, x_local_agent_token: str | None = Header(default=None)) -> None:
    if not x_local_agent_token or x_local_agent_token != expected_token:
        raise HTTPException(status_code=403, detail="Missing or invalid local-agent token.")
