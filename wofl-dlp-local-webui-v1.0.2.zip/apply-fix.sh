#!/usr/bin/env bash
# wofl-dlp YouTube n-cipher fix — May 2026
# ----------------------------------------
# Run this from inside your wofl-dlp project directory:
#   cd ~/yt-dlp-site/wofl-dlp
#   bash apply-fix.sh
#
# It does three things:
#   1. patches your settings.json so EJS remote components are enabled
#      and your cookies.txt path is set
#   2. applies the source patch to app/models.py, app/ytdlp_runner.py,
#      app/static/index.html, requirements.txt, and static/index.html
#   3. upgrades yt-dlp + yt-dlp-ejs inside your existing .venv
#
# Safe to re-run.

set -euo pipefail

PROJECT_ROOT="$(pwd)"
COOKIES="${PROJECT_ROOT}/cookies.txt"

if [[ ! -d app || ! -f requirements.txt ]]; then
  echo "ERROR: run this from the wofl-dlp project root (the one containing app/ and requirements.txt)." >&2
  exit 1
fi

# 1) settings.json
echo "[1/3] patching ~/.config/wofl-dlp/settings.json ..."
python3 - <<PY
import json, pathlib
p = pathlib.Path.home() / ".config/wofl-dlp/settings.json"
p.parent.mkdir(parents=True, exist_ok=True)
s = json.loads(p.read_text()) if p.exists() else {}
s["allow_remote_ejs_github"] = True
if not s.get("cookies_file"):
    s["cookies_file"] = "${COOKIES}"
p.write_text(json.dumps(s, indent=2) + "\n")
print("   ->", p)
print("  ", json.dumps(s, indent=2))
PY

# 2) source patch
echo "[2/3] applying source patch ..."
patch -p0 --forward --reject-file=- < wofl-dlp.patch || {
  echo "   patch already applied or partial — continuing"
}

# 3) refresh deps in .venv
if [[ -x ".venv/bin/pip" ]]; then
  echo "[3/3] upgrading yt-dlp + yt-dlp-ejs in .venv ..."
  .venv/bin/pip install --upgrade --quiet \
      'yt-dlp[default]>=2026.02.04' 'yt-dlp-ejs>=0.7.0'
  .venv/bin/python -c "import yt_dlp; print('   yt-dlp:', yt_dlp.version.__version__)"
  .venv/bin/python -c "import yt_dlp_ejs; print('   yt-dlp-ejs:', getattr(yt_dlp_ejs, '__version__', 'installed'))" 2>/dev/null || true
else
  echo "[3/3] no .venv found at ./.venv — skip dep refresh (run your usual installer)."
fi

# also bin the stale solver cache so a fresh script gets fetched on next run
SOLVER_CACHE="${HOME}/.cache/yt-dlp/challenge-solver"
if [[ -d "$SOLVER_CACHE" ]]; then
  echo "    clearing stale solver cache at $SOLVER_CACHE"
  rm -rf "$SOLVER_CACHE"
fi

echo
echo "Done. Restart wofl-dlp and try the download again."
